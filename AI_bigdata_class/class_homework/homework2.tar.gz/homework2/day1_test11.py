#11

#
a = [1,3,4,5,6,7,8,9,10,11,12,13] # list 생성

for unit in a:
    if unit % 2 == 0:
        print(unit, end=" ")

