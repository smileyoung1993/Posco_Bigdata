#10

#
colors = ["red","green","blue"]

for color in colors:
    print(color)