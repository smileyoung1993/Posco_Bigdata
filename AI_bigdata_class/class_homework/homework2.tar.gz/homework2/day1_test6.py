#6

# 10,9,8,7,6,5,4,3,2,1,Happy new year!! 출력

str = "10,9,8,7,6,5,4,3,2,1,Happy new year!!"

str_lst = list(str)

for word in str_lst:
    print(word,end="")