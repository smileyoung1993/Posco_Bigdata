#4

# 대소비교
'''

def judgement(x,y,z):

    if x > y :
        if x > z:
            max = x

    elif y > x:
        if y > z:
            max = y
    elif z > x:




# main
num1,num2,num3 = map(int,input("세 개의 수를 입력하시오 : ").split())

judgement(num1,num2,num3)
'''